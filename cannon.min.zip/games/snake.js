// Neon Snake Game
class SnakeGame {
  constructor(canvas, app) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.app = app;
    this.id = 'snake';
    this.name = 'Neon Snake';

    this.width = canvas.width;
    this.height = canvas.height;

    this.gridSize = 20;
    this.cols = Math.floor(this.width / this.gridSize);
    this.rows = Math.floor(this.height / this.gridSize);

    this.resetState();
  }

  resetState() {
    this.score = 0;
    this.level = 1;
    this.state = 'ready'; // ready, playing, gameover

    const startX = Math.floor(this.cols / 2);
    const startY = Math.floor(this.rows / 2);

    this.snake = [
      { x: startX, y: startY },
      { x: startX - 1, y: startY },
      { x: startX - 2, y: startY }
    ];

    this.dir = { x: 1, y: 0 };
    this.nextDir = { x: 1, y: 0 };

    this.moveTimer = 0;
    this.moveInterval = 0.11; // Base speed ~9 steps/sec
    this.combo = 0;
    this.comboTimer = 0;

    this.food = null;
    this.bonusFood = null;
    this.bonusTimer = 0;
    this.particles = [];

    this.spawnFood();
  }

  spawnFood() {
    let valid = false;
    while (!valid) {
      const fx = Math.floor(Math.random() * (this.cols - 2)) + 1;
      const fy = Math.floor(Math.random() * (this.rows - 2)) + 1;
      if (!this.snake.some(seg => seg.x === fx && seg.y === fy)) {
        this.food = { x: fx, y: fy, color: '#00ff66', pulse: 0 };
        valid = true;
      }
    }
  }

  spawnBonusFood() {
    let valid = false;
    while (!valid) {
      const fx = Math.floor(Math.random() * (this.cols - 2)) + 1;
      const fy = Math.floor(Math.random() * (this.rows - 2)) + 1;
      if (!this.snake.some(seg => seg.x === fx && seg.y === fy) &&
          (!this.food || this.food.x !== fx || this.food.y !== fy)) {
        this.bonusFood = {
          x: fx,
          y: fy,
          color: '#ffe600',
          maxTime: 7.0,
          timeRemaining: 7.0
        };
        valid = true;
      }
    }
  }

  start() {
    if (this.state === 'ready') {
      this.state = 'playing';
      window.soundEngine.playBounce();
    } else if (this.state === 'gameover') {
      this.resetState();
      this.state = 'playing';
      window.soundEngine.playCoin();
    }
  }

  handleInput(action, active) {
    if (!active) return;

    if (this.state === 'ready' || this.state === 'gameover') {
      if (action === 'action' || action === 'up' || action === 'down' || action === 'left' || action === 'right') {
        this.start();
        return;
      }
    }

    if (action === 'up' && this.dir.y === 0) {
      this.nextDir = { x: 0, y: -1 };
    } else if (action === 'down' && this.dir.y === 0) {
      this.nextDir = { x: 0, y: 1 };
    } else if (action === 'left' && this.dir.x === 0) {
      this.nextDir = { x: -1, y: 0 };
    } else if (action === 'right' && this.dir.x === 0) {
      this.nextDir = { x: 1, y: 0 };
    }
  }

  update(dt) {
    // Update Particles
    this.updateParticles(dt);

    if (this.state !== 'playing') return;

    // Bonus food countdown
    if (this.bonusFood) {
      this.bonusFood.timeRemaining -= dt;
      if (this.bonusFood.timeRemaining <= 0) {
        this.bonusFood = null;
      }
    }

    // Combo countdown
    if (this.comboTimer > 0) {
      this.comboTimer -= dt;
      if (this.comboTimer <= 0) {
        this.combo = 0;
      }
    }

    // Step Timer
    this.moveTimer += dt;
    if (this.moveTimer >= this.moveInterval) {
      this.moveTimer = 0;
      this.step();
    }
  }

  step() {
    this.dir = { ...this.nextDir };
    const head = this.snake[0];
    const newHead = {
      x: head.x + this.dir.x,
      y: head.y + this.dir.y
    };

    // Wall Collision
    if (newHead.x < 0 || newHead.x >= this.cols || newHead.y < 0 || newHead.y >= this.rows) {
      this.triggerGameOver();
      return;
    }

    // Self Collision
    if (this.snake.some(seg => seg.x === newHead.x && seg.y === newHead.y)) {
      this.triggerGameOver();
      return;
    }

    // Move
    this.snake.unshift(newHead);

    // Food Collision
    let ate = false;
    if (this.food && newHead.x === this.food.x && newHead.y === this.food.y) {
      ate = true;
      this.combo++;
      this.comboTimer = 3.5;
      const points = 100 * (1 + Math.floor(this.combo / 2));
      this.score += points;

      window.soundEngine.playCoin();
      this.createFoodSparks(newHead.x * this.gridSize + 10, newHead.y * this.gridSize + 10, '#00ff66');
      this.spawnFood();

      // Chance for bonus golden food
      if (!this.bonusFood && Math.random() < 0.35) {
        this.spawnBonusFood();
      }

      // Speed up slightly as snake lengthens
      this.moveInterval = Math.max(0.055, 0.11 - Math.floor(this.snake.length / 5) * 0.005);
      this.level = 1 + Math.floor(this.snake.length / 6);
    }

    // Bonus Food Collision
    if (this.bonusFood && newHead.x === this.bonusFood.x && newHead.y === this.bonusFood.y) {
      ate = true;
      this.score += 400;
      window.soundEngine.playPowerup();
      this.createFoodSparks(newHead.x * this.gridSize + 10, newHead.y * this.gridSize + 10, '#ffe600');
      this.bonusFood = null;
    }

    if (!ate) {
      this.snake.pop();
    }
  }

  triggerGameOver() {
    this.state = 'gameover';
    window.soundEngine.playGameOver();
    const head = this.snake[0];
    this.createFoodSparks(head.x * this.gridSize + 10, head.y * this.gridSize + 10, '#ff0055', 30);
    this.app.saveHighScore(this.id, this.score);
  }

  createFoodSparks(x, y, color, count = 14) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 50 + Math.random() * 120;
      this.particles.push({
        x: x,
        y: y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color: color,
        size: 2 + Math.random() * 3,
        alpha: 1,
        life: 0.3 + Math.random() * 0.3
      });
    }
  }

  updateParticles(dt) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.alpha -= dt / p.life;
      if (p.alpha <= 0) {
        this.particles.splice(i, 1);
      }
    }
  }

  draw() {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.width, this.height);

    // Subtle grid
    ctx.strokeStyle = 'rgba(0, 255, 102, 0.05)';
    ctx.lineWidth = 1;
    for (let x = 0; x < this.width; x += this.gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, this.height);
      ctx.stroke();
    }
    for (let y = 0; y < this.height; y += this.gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(this.width, y);
      ctx.stroke();
    }

    // Draw Bonus Food
    if (this.bonusFood) {
      ctx.save();
      const bx = this.bonusFood.x * this.gridSize + this.gridSize / 2;
      const by = this.bonusFood.y * this.gridSize + this.gridSize / 2;
      ctx.shadowColor = '#ffe600';
      ctx.shadowBlur = 15;
      ctx.fillStyle = '#ffe600';
      ctx.beginPath();
      ctx.arc(bx, by, 7, 0, Math.PI * 2);
      ctx.fill();

      // Countdown Ring
      const pct = this.bonusFood.timeRemaining / this.bonusFood.maxTime;
      ctx.strokeStyle = '#ffe600';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(bx, by, 11, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * pct);
      ctx.stroke();
      ctx.restore();
    }

    // Draw Regular Food
    if (this.food) {
      ctx.save();
      const fx = this.food.x * this.gridSize + this.gridSize / 2;
      const fy = this.food.y * this.gridSize + this.gridSize / 2;
      ctx.shadowColor = '#00ff66';
      ctx.shadowBlur = 12;
      ctx.fillStyle = '#00ff66';
      ctx.beginPath();
      ctx.arc(fx, fy, 6, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(fx - 2, fy - 2, 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Draw Snake
    for (let i = this.snake.length - 1; i >= 0; i--) {
      const seg = this.snake[i];
      const px = seg.x * this.gridSize;
      const py = seg.y * this.gridSize;
      const isHead = i === 0;

      ctx.save();
      if (isHead) {
        ctx.shadowColor = '#00f0ff';
        ctx.shadowBlur = 16;
        ctx.fillStyle = '#00f0ff';
        ctx.beginPath();
        ctx.roundRect(px + 1, py + 1, this.gridSize - 2, this.gridSize - 2, 5);
        ctx.fill();

        // Eyes
        ctx.fillStyle = '#0a0f1d';
        const eyeOffset = 4;
        let e1x = px + 4, e1y = py + 4, e2x = px + 12, e2y = py + 4;
        if (this.dir.x === 1) {
          e1x = px + 12; e1y = py + 4;
          e2x = px + 12; e2y = py + 12;
        } else if (this.dir.x === -1) {
          e1x = px + 4; e1y = py + 4;
          e2x = px + 4; e2y = py + 12;
        } else if (this.dir.y === 1) {
          e1x = px + 4; e1y = py + 12;
          e2x = px + 12; e2y = py + 12;
        }
        ctx.fillRect(e1x, e1y, 3, 3);
        ctx.fillRect(e2x, e2y, 3, 3);
      } else {
        const ratio = 1 - (i / this.snake.length) * 0.6;
        ctx.shadowColor = '#00f0ff';
        ctx.shadowBlur = 6;
        ctx.fillStyle = `rgba(0, 240, 255, ${ratio})`;
        ctx.beginPath();
        ctx.roundRect(px + 2, py + 2, this.gridSize - 4, this.gridSize - 4, 3);
        ctx.fill();
      }
      ctx.restore();
    }

    // Draw Particles
    for (const p of this.particles) {
      ctx.save();
      ctx.fillStyle = p.color;
      ctx.globalAlpha = Math.max(0, p.alpha);
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 6;
      ctx.fillRect(p.x, p.y, p.size, p.size);
      ctx.restore();
    }

    // Draw HUD
    this.drawHUD(ctx);

    // Overlay Screens
    if (this.state === 'ready') {
      this.drawCenteredBanner(ctx, 'PRESS ANY ARROW OR TAP TO START', '방향키(WASD) 또는 화면 터치로 뱀 조작');
    } else if (this.state === 'gameover') {
      this.drawCenteredBanner(ctx, 'CRASHED!', `최종 점수: ${this.score} (SPACE / 터치로 재시작)`, '#ff0055');
    }
  }

  drawHUD(ctx) {
    ctx.save();
    ctx.font = '12px "Press Start 2P", monospace';
    ctx.fillStyle = '#00ff66';
    ctx.textAlign = 'left';
    ctx.fillText(`SCORE: ${this.score}`, 18, 26);

    ctx.fillStyle = '#00f0ff';
    ctx.fillText(`LENGTH: ${this.snake.length}`, 220, 26);

    if (this.combo > 1) {
      ctx.fillStyle = '#ffe600';
      ctx.fillText(`COMBO x${this.combo}`, 380, 26);
    }
    ctx.restore();
  }

  drawCenteredBanner(ctx, title, subtitle, color = '#00ff66') {
    ctx.save();
    ctx.fillStyle = 'rgba(10, 15, 30, 0.75)';
    ctx.fillRect(0, this.height / 2 - 50, this.width, 100);

    ctx.shadowColor = color;
    ctx.shadowBlur = 12;
    ctx.fillStyle = color;
    ctx.font = '18px "Press Start 2P", monospace';
    ctx.textAlign = 'center';
    ctx.fillText(title, this.width / 2, this.height / 2 - 8);

    ctx.shadowBlur = 0;
    ctx.fillStyle = '#94a3b8';
    ctx.font = '12px "Pretendard", sans-serif';
    ctx.fillText(subtitle, this.width / 2, this.height / 2 + 25);
    ctx.restore();
  }

  destroy() {
    this.particles = [];
  }
}

window.SnakeGame = SnakeGame;
