// Galactic Defender (Space Shooter) Game
class InvadersGame {
  constructor(canvas, app) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.app = app;
    this.id = 'invaders';
    this.name = 'Galactic Defender';

    this.width = canvas.width;
    this.height = canvas.height;

    this.stars = [];
    this.initStars();
    this.resetState();
  }

  initStars() {
    this.stars = [];
    for (let i = 0; i < 70; i++) {
      this.stars.push({
        x: Math.random() * this.width,
        y: Math.random() * this.height,
        size: Math.random() * 2 + 1,
        speed: Math.random() * 80 + 30,
        alpha: Math.random() * 0.8 + 0.2
      });
    }
  }

  resetState() {
    this.score = 0;
    this.lives = 3;
    this.wave = 1;
    this.state = 'ready'; // ready, playing, gameover

    this.player = {
      x: this.width / 2 - 18,
      y: this.height - 45,
      w: 36,
      h: 28,
      speed: 400,
      dx: 0,
      dy: 0,
      shootCooldown: 0,
      weaponLevel: 1,
      shield: false,
      invulnerable: 0
    };

    this.playerBullets = [];
    this.enemyBullets = [];
    this.enemies = [];
    this.particles = [];
    this.powerups = [];
    this.boss = null;
    this.screenShake = 0;

    this.spawnWave();
  }

  spawnWave() {
    this.enemies = [];
    this.enemyBullets = [];

    // Boss wave every 3 waves
    if (this.wave % 3 === 0) {
      this.spawnBoss();
      return;
    }

    const rows = 3 + Math.min(2, Math.floor(this.wave / 2));
    const cols = 8;
    const startX = 90;
    const startY = 60;
    const spacingX = (this.width - startX * 2) / (cols - 1);
    const spacingY = 38;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        let type = 'grunt';
        let hp = 1;
        let color = '#00f0ff';

        if (r === 0) {
          type = 'elite';
          hp = 2;
          color = '#ff007f';
        } else if (r === 1) {
          type = 'medium';
          hp = 1;
          color = '#ffe600';
        }

        this.enemies.push({
          x: startX + c * spacingX,
          y: startY + r * spacingY,
          baseX: startX + c * spacingX,
          baseY: startY + r * spacingY,
          w: 26,
          h: 22,
          type: type,
          hp: hp,
          maxHp: hp,
          color: color,
          shootTimer: Math.random() * 3 + 1,
          alive: true
        });
      }
    }

    this.waveDirection = 1;
    this.waveOffset = 0;
  }

  spawnBoss() {
    this.boss = {
      x: this.width / 2 - 60,
      y: 70,
      w: 120,
      h: 50,
      hp: 35 + this.wave * 15,
      maxHp: 35 + this.wave * 15,
      speed: 120,
      dir: 1,
      shootTimer: 1.0,
      color: '#a855f7'
    };
    window.soundEngine.playPowerup();
  }

  start() {
    if (this.state === 'ready') {
      this.state = 'playing';
      window.soundEngine.playBounce();
    } else if (this.state === 'gameover') {
      this.resetState();
      this.state = 'playing';
      window.soundEngine.playCoin();
    }
  }

  handleInput(action, active, val) {
    if (action === 'left') {
      this.player.dx = active ? -1 : (this.player.dx === -1 ? 0 : this.player.dx);
    } else if (action === 'right') {
      this.player.dx = active ? 1 : (this.player.dx === 1 ? 0 : this.player.dx);
    } else if (action === 'action' && active) {
      if (this.state === 'ready' || this.state === 'gameover') {
        this.start();
      } else if (this.state === 'playing') {
        this.fireBullet();
      }
    } else if (action === 'pointermove') {
      const rect = this.canvas.getBoundingClientRect();
      const scaleX = this.canvas.width / rect.width;
      const mouseX = (val.clientX - rect.left) * scaleX;
      this.player.x = Math.max(10, Math.min(this.width - this.player.w - 10, mouseX - this.player.w / 2));
    } else if (action === 'pointerdown') {
      if (this.state === 'ready' || this.state === 'gameover') {
        this.start();
      } else if (this.state === 'playing') {
        this.fireBullet();
      }
    }
  }

  fireBullet() {
    if (this.player.shootCooldown > 0) return;
    this.player.shootCooldown = 0.16;

    const px = this.player.x + this.player.w / 2;
    const py = this.player.y;

    if (this.player.weaponLevel === 1) {
      this.playerBullets.push({ x: px, y: py, vx: 0, vy: -580, color: '#00f0ff' });
    } else if (this.player.weaponLevel === 2) {
      this.playerBullets.push({ x: px - 8, y: py, vx: 0, vy: -580, color: '#00f0ff' });
      this.playerBullets.push({ x: px + 8, y: py, vx: 0, vy: -580, color: '#00f0ff' });
    } else {
      this.playerBullets.push({ x: px, y: py, vx: 0, vy: -600, color: '#ffe600' });
      this.playerBullets.push({ x: px - 10, y: py, vx: -120, vy: -580, color: '#ff007f' });
      this.playerBullets.push({ x: px + 10, y: py, vx: 120, vy: -580, color: '#ff007f' });
    }

    window.soundEngine.playLaser();
  }

  update(dt) {
    // Parallax Stars
    for (const star of this.stars) {
      star.y += star.speed * dt;
      if (star.y > this.height) {
        star.y = 0;
        star.x = Math.random() * this.width;
      }
    }

    // Screen Shake
    if (this.screenShake > 0) {
      this.screenShake -= dt * 20;
      if (this.screenShake < 0) this.screenShake = 0;
    }

    // Update Particles
    this.updateParticles(dt);

    if (this.state !== 'playing') return;

    // Player Cooldowns
    if (this.player.shootCooldown > 0) this.player.shootCooldown -= dt;
    if (this.player.invulnerable > 0) this.player.invulnerable -= dt;

    // Player Movement
    this.player.x += this.player.dx * this.player.speed * dt;
    this.player.x = Math.max(10, Math.min(this.width - this.player.w - 10, this.player.x));

    // Player Bullets
    for (let i = this.playerBullets.length - 1; i >= 0; i--) {
      const b = this.playerBullets[i];
      b.x += b.vx * dt;
      b.y += b.vy * dt;

      if (b.y < -10) {
        this.playerBullets.splice(i, 1);
        continue;
      }

      // Check bullet vs boss
      if (this.boss) {
        if (b.x >= this.boss.x && b.x <= this.boss.x + this.boss.w &&
            b.y >= this.boss.y && b.y <= this.boss.y + this.boss.h) {
          this.boss.hp--;
          this.score += 20;
          this.createSparks(b.x, b.y, '#a855f7', 4);
          this.playerBullets.splice(i, 1);
          window.soundEngine.playHit();

          if (this.boss.hp <= 0) {
            this.triggerBossDefeat();
          }
          continue;
        }
      }

      // Check bullet vs enemies
      let hit = false;
      for (const e of this.enemies) {
        if (!e.alive) continue;
        if (b.x >= e.x && b.x <= e.x + e.w && b.y >= e.y && b.y <= e.y + e.h) {
          hit = true;
          e.hp--;
          if (e.hp <= 0) {
            e.alive = false;
            this.score += (e.type === 'elite' ? 150 : (e.type === 'medium' ? 100 : 60));
            window.soundEngine.playExplosion();
            this.createSparks(e.x + e.w / 2, e.y + e.h / 2, e.color, 16);

            // Chance to drop power-up
            if (Math.random() < 0.18) {
              this.spawnPowerup(e.x + e.w / 2, e.y + e.h / 2);
            }
          } else {
            window.soundEngine.playHit();
            this.createSparks(b.x, b.y, e.color, 5);
          }
          break;
        }
      }

      if (hit) {
        this.playerBullets.splice(i, 1);
      }
    }

    // Update Boss
    if (this.boss) {
      this.boss.x += this.boss.speed * this.boss.dir * dt;
      if (this.boss.x < 30 || this.boss.x + this.boss.w > this.width - 30) {
        this.boss.dir *= -1;
      }

      this.boss.shootTimer -= dt;
      if (this.boss.shootTimer <= 0) {
        this.boss.shootTimer = 0.8;
        // Radial boss shots
        [-100, 0, 100].forEach(vx => {
          this.enemyBullets.push({
            x: this.boss.x + this.boss.w / 2,
            y: this.boss.y + this.boss.h,
            vx: vx,
            vy: 240,
            color: '#ff0055'
          });
        });
      }
    }

    // Update Enemies (Wave movement)
    this.waveOffset += this.waveDirection * 50 * dt;
    if (Math.abs(this.waveOffset) > 60) {
      this.waveDirection *= -1;
    }

    for (const e of this.enemies) {
      if (!e.alive) continue;
      e.x = e.baseX + this.waveOffset;

      // Enemy shooting
      e.shootTimer -= dt;
      if (e.shootTimer <= 0) {
        e.shootTimer = Math.random() * 5 + 2;
        this.enemyBullets.push({
          x: e.x + e.w / 2,
          y: e.y + e.h,
          vx: 0,
          vy: 220,
          color: e.color
        });
      }
    }

    // Update Enemy Bullets
    for (let i = this.enemyBullets.length - 1; i >= 0; i--) {
      const eb = this.enemyBullets[i];
      eb.x += eb.vx * dt;
      eb.y += eb.vy * dt;

      if (eb.y > this.height) {
        this.enemyBullets.splice(i, 1);
        continue;
      }

      // Check hit on player
      if (
        this.player.invulnerable <= 0 &&
        eb.x >= this.player.x && eb.x <= this.player.x + this.player.w &&
        eb.y >= this.player.y && eb.y <= this.player.y + this.player.h
      ) {
        this.enemyBullets.splice(i, 1);
        this.hitPlayer();
      }
    }

    // Update Power-ups
    for (let i = this.powerups.length - 1; i >= 0; i--) {
      const p = this.powerups[i];
      p.y += p.speed * dt;

      if (
        p.y + 12 >= this.player.y &&
        p.y - 12 <= this.player.y + this.player.h &&
        p.x + 12 >= this.player.x &&
        p.x - 12 <= this.player.x + this.player.w
      ) {
        this.applyPowerup(p.type);
        window.soundEngine.playPowerup();
        this.createSparks(p.x, p.y, p.color, 14);
        this.powerups.splice(i, 1);
        continue;
      }

      if (p.y > this.height) {
        this.powerups.splice(i, 1);
      }
    }

    // Check Wave Clear
    if (!this.boss && this.enemies.length > 0 && this.enemies.every(e => !e.alive)) {
      this.wave++;
      this.score += 500;
      window.soundEngine.playVictory();
      this.spawnWave();
    }
  }

  triggerBossDefeat() {
    window.soundEngine.playExplosion();
    this.createSparks(this.boss.x + this.boss.w / 2, this.boss.y + this.boss.h / 2, '#a855f7', 45);
    this.screenShake = 12;
    this.score += 2000;
    this.boss = null;
    this.wave++;
    window.soundEngine.playVictory();
    setTimeout(() => this.spawnWave(), 1200);
  }

  hitPlayer() {
    if (this.player.shield) {
      this.player.shield = false;
      this.player.invulnerable = 1.0;
      window.soundEngine.playHit();
      this.createSparks(this.player.x + this.player.w / 2, this.player.y + this.player.h / 2, '#00f0ff', 18);
      return;
    }

    this.lives--;
    this.screenShake = 10;
    this.player.invulnerable = 2.0;
    this.player.weaponLevel = Math.max(1, this.player.weaponLevel - 1);
    window.soundEngine.playExplosion();
    this.createSparks(this.player.x + this.player.w / 2, this.player.y + this.player.h / 2, '#ff0055', 25);

    if (this.lives <= 0) {
      this.state = 'gameover';
      window.soundEngine.playGameOver();
      this.app.saveHighScore(this.id, this.score);
    }
  }

  spawnPowerup(x, y) {
    const types = [
      { type: 'weapon', label: '⚔️', color: '#ffe600' },
      { type: 'shield', label: '🛡️', color: '#00f0ff' },
      { type: 'bomb', label: '💣', color: '#ff0055' }
    ];
    const chosen = types[Math.floor(Math.random() * types.length)];
    this.powerups.push({
      x: x,
      y: y,
      type: chosen.type,
      label: chosen.label,
      color: chosen.color,
      speed: 110
    });
  }

  applyPowerup(type) {
    if (type === 'weapon') {
      this.player.weaponLevel = Math.min(3, this.player.weaponLevel + 1);
    } else if (type === 'shield') {
      this.player.shield = true;
    } else if (type === 'bomb') {
      // Smart bomb clears all active enemy bullets and damages enemies
      this.enemyBullets = [];
      this.screenShake = 10;
      window.soundEngine.playExplosion();
      this.enemies.forEach(e => {
        if (e.alive) {
          e.hp--;
          if (e.hp <= 0) {
            e.alive = false;
            this.score += 80;
            this.createSparks(e.x + e.w / 2, e.y + e.h / 2, e.color, 12);
          }
        }
      });
      if (this.boss) {
        this.boss.hp -= 5;
      }
    }
  }

  createSparks(x, y, color, count = 12) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 40 + Math.random() * 160;
      this.particles.push({
        x: x,
        y: y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color: color,
        size: 2 + Math.random() * 3,
        alpha: 1,
        life: 0.3 + Math.random() * 0.3
      });
    }
  }

  updateParticles(dt) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.alpha -= dt / p.life;
      if (p.alpha <= 0) {
        this.particles.splice(i, 1);
      }
    }
  }

  draw() {
    const ctx = this.ctx;
    ctx.save();

    // Screen Shake effect
    if (this.screenShake > 0) {
      const dx = (Math.random() - 0.5) * this.screenShake;
      const dy = (Math.random() - 0.5) * this.screenShake;
      ctx.translate(dx, dy);
    }

    ctx.clearRect(0, 0, this.width, this.height);

    // Draw Parallax Stars
    for (const star of this.stars) {
      ctx.fillStyle = `rgba(255, 255, 255, ${star.alpha})`;
      ctx.fillRect(star.x, star.y, star.size, star.size);
    }

    // Draw Boss
    if (this.boss) {
      ctx.save();
      ctx.shadowColor = this.boss.color;
      ctx.shadowBlur = 20;
      ctx.fillStyle = '#1e1035';
      ctx.strokeStyle = this.boss.color;
      ctx.lineWidth = 3;

      // Boss Body
      ctx.beginPath();
      ctx.moveTo(this.boss.x, this.boss.y);
      ctx.lineTo(this.boss.x + this.boss.w, this.boss.y);
      ctx.lineTo(this.boss.x + this.boss.w - 20, this.boss.y + this.boss.h);
      ctx.lineTo(this.boss.x + 20, this.boss.y + this.boss.h);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Boss Core Eye
      ctx.fillStyle = '#ff0055';
      ctx.beginPath();
      ctx.arc(this.boss.x + this.boss.w / 2, this.boss.y + this.boss.h / 2, 12, 0, Math.PI * 2);
      ctx.fill();

      // Boss HP Bar
      const hpPct = this.boss.hp / this.boss.maxHp;
      ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.fillRect(this.boss.x, this.boss.y - 12, this.boss.w, 6);
      ctx.fillStyle = '#ff0055';
      ctx.fillRect(this.boss.x, this.boss.y - 12, this.boss.w * hpPct, 6);
      ctx.restore();
    }

    // Draw Enemies
    for (const e of this.enemies) {
      if (!e.alive) continue;
      ctx.save();
      ctx.shadowColor = e.color;
      ctx.shadowBlur = 10;
      ctx.fillStyle = e.color;

      // Draw stylized alien drone
      ctx.beginPath();
      ctx.moveTo(e.x + e.w / 2, e.y + e.h);
      ctx.lineTo(e.x + e.w, e.y);
      ctx.lineTo(e.x + e.w / 2, e.y + 6);
      ctx.lineTo(e.x, e.y);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }

    // Draw Power-ups
    for (const p of this.powerups) {
      ctx.save();
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 12;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 12, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#0a0f1d';
      ctx.font = '12px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(p.label, p.x, p.y);
      ctx.restore();
    }

    // Draw Bullets
    for (const b of this.playerBullets) {
      ctx.save();
      ctx.shadowColor = b.color;
      ctx.shadowBlur = 8;
      ctx.fillStyle = b.color;
      ctx.fillRect(b.x - 2, b.y, 4, 12);
      ctx.restore();
    }

    for (const eb of this.enemyBullets) {
      ctx.save();
      ctx.shadowColor = eb.color;
      ctx.shadowBlur = 8;
      ctx.fillStyle = eb.color;
      ctx.beginPath();
      ctx.arc(eb.x, eb.y, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Draw Player Ship
    if (this.player.invulnerable <= 0 || Math.floor(Date.now() / 100) % 2 === 0) {
      ctx.save();
      ctx.shadowColor = '#00f0ff';
      ctx.shadowBlur = 16;
      ctx.fillStyle = '#00f0ff';

      // Triangle / Spaceship shape
      const px = this.player.x;
      const py = this.player.y;
      ctx.beginPath();
      ctx.moveTo(px + this.player.w / 2, py);
      ctx.lineTo(px + this.player.w, py + this.player.h);
      ctx.lineTo(px + this.player.w / 2, py + this.player.h - 6);
      ctx.lineTo(px, py + this.player.h);
      ctx.closePath();
      ctx.fill();

      // Thruster flame
      ctx.fillStyle = '#ff5500';
      ctx.beginPath();
      ctx.moveTo(px + this.player.w / 2 - 4, py + this.player.h - 4);
      ctx.lineTo(px + this.player.w / 2 + 4, py + this.player.h - 4);
      ctx.lineTo(px + this.player.w / 2, py + this.player.h + 8 + Math.random() * 4);
      ctx.closePath();
      ctx.fill();

      // Shield Bubble
      if (this.player.shield) {
        ctx.strokeStyle = '#00f0ff';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(px + this.player.w / 2, py + this.player.h / 2, this.player.w * 0.8, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();
    }

    // Draw Particles
    for (const p of this.particles) {
      ctx.save();
      ctx.fillStyle = p.color;
      ctx.globalAlpha = Math.max(0, p.alpha);
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 6;
      ctx.fillRect(p.x, p.y, p.size, p.size);
      ctx.restore();
    }

    ctx.restore(); // Restore shake translate

    // Draw HUD
    this.drawHUD(ctx);

    // Overlay Screens
    if (this.state === 'ready') {
      this.drawCenteredBanner(ctx, 'PRESS SPACE OR TAP TO ENGAGE', '좌우 이동으로 조작하고 스페이스바로 사격');
    } else if (this.state === 'gameover') {
      this.drawCenteredBanner(ctx, 'FLEET DESTROYED', `최종 점수: ${this.score} (SPACE / 터치로 재시작)`, '#ff0055');
    }
  }

  drawHUD(ctx) {
    ctx.save();
    ctx.font = '12px "Press Start 2P", monospace';
    ctx.fillStyle = '#00f0ff';
    ctx.textAlign = 'left';
    ctx.fillText(`SCORE: ${this.score}`, 18, 26);

    ctx.fillStyle = '#ffe600';
    ctx.fillText(`WAVE: ${this.wave}`, 220, 26);

    if (this.player.weaponLevel > 1) {
      ctx.fillStyle = '#ff007f';
      ctx.fillText(`WEAPON: LV${this.player.weaponLevel}`, 340, 26);
    }

    // Lives
    ctx.textAlign = 'right';
    let ships = '';
    for (let i = 0; i < this.lives; i++) ships += '🚀 ';
    ctx.fillStyle = '#00f0ff';
    ctx.font = '14px sans-serif';
    ctx.fillText(ships, this.width - 18, 26);
    ctx.restore();
  }

  drawCenteredBanner(ctx, title, subtitle, color = '#00f0ff') {
    ctx.save();
    ctx.fillStyle = 'rgba(10, 15, 30, 0.75)';
    ctx.fillRect(0, this.height / 2 - 50, this.width, 100);

    ctx.shadowColor = color;
    ctx.shadowBlur = 12;
    ctx.fillStyle = color;
    ctx.font = '18px "Press Start 2P", monospace';
    ctx.textAlign = 'center';
    ctx.fillText(title, this.width / 2, this.height / 2 - 8);

    ctx.shadowBlur = 0;
    ctx.fillStyle = '#94a3b8';
    ctx.font = '12px "Pretendard", sans-serif';
    ctx.fillText(subtitle, this.width / 2, this.height / 2 + 25);
    ctx.restore();
  }

  destroy() {
    this.particles = [];
  }
}

window.InvadersGame = InvadersGame;
