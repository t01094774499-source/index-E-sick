// Cyber Breakout Game
class BreakoutGame {
  constructor(canvas, app) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.app = app;
    this.id = 'breakout';
    this.name = 'Cyber Breakout';

    this.width = canvas.width;
    this.height = canvas.height;

    this.resetState();
  }

  resetState() {
    this.score = 0;
    this.lives = 3;
    this.level = 1;
    this.combo = 0;
    this.maxCombo = 0;
    this.state = 'ready'; // ready, playing, gameover, victory

    this.paddle = {
      x: this.width / 2 - 60,
      y: this.height - 35,
      w: 120,
      h: 14,
      baseW: 120,
      speed: 550,
      dx: 0,
      laserActive: false,
      laserTimer: 0
    };

    this.balls = [];
    this.bricks = [];
    this.particles = [];
    this.powerups = [];
    this.lasers = [];

    this.initBricks();
    this.spawnBall(true);
  }

  spawnBall(attached = false) {
    const ball = {
      x: this.paddle.x + this.paddle.w / 2,
      y: this.paddle.y - 10,
      radius: 7,
      vx: (Math.random() - 0.5) * 200,
      vy: -320,
      attached: attached,
      trail: []
    };
    this.balls.push(ball);
  }

  initBricks() {
    this.bricks = [];
    const rows = 5 + Math.min(this.level, 3);
    const cols = 9;
    const padding = 8;
    const offsetTop = 50;
    const offsetLeft = 35;
    const brickW = (this.width - offsetLeft * 2 - (cols - 1) * padding) / cols;
    const brickH = 20;

    const colors = [
      { fill: '#ff007f', border: '#ff77bb', points: 50 },
      { fill: '#00f0ff', border: '#70ffff', points: 40 },
      { fill: '#ffe600', border: '#fff580', points: 30 },
      { fill: '#00ff66', border: '#80ffb3', points: 20 },
      { fill: '#a855f7', border: '#c084fc', points: 10 },
      { fill: '#ff5500', border: '#ff884d', points: 15 }
    ];

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        let type = 'normal';
        let hits = 1;
        const rand = Math.random();

        if (rand < 0.12 && r > 0) {
          type = 'bomb'; // 폭탄 벽돌
        } else if (rand < 0.25 && r > 1) {
          type = 'hard'; // 2번 쳐야 깨지는 단단한 벽돌
          hits = 2;
        }

        const colorInfo = colors[r % colors.length];
        this.bricks.push({
          x: offsetLeft + c * (brickW + padding),
          y: offsetTop + r * (brickH + padding),
          w: brickW,
          h: brickH,
          type: type,
          hits: hits,
          maxHits: hits,
          color: type === 'bomb' ? '#ff1e27' : (type === 'hard' ? '#9333ea' : colorInfo.fill),
          border: type === 'bomb' ? '#ff9999' : (type === 'hard' ? '#e9d5ff' : colorInfo.border),
          points: colorInfo.points * hits,
          alive: true
        });
      }
    }
  }

  start() {
    if (this.state === 'ready') {
      this.state = 'playing';
      this.balls.forEach(b => {
        b.attached = false;
        b.vx = (Math.random() > 0.5 ? 1 : -1) * (180 + Math.random() * 80);
        b.vy = -340;
      });
      window.soundEngine.playBounce();
    } else if (this.state === 'gameover' || this.state === 'victory') {
      this.resetState();
      this.state = 'playing';
      this.balls.forEach(b => {
        b.attached = false;
        b.vx = 220;
        b.vy = -340;
      });
      window.soundEngine.playCoin();
    }
  }

  update(dt) {
    if (this.state !== 'playing' && this.state !== 'ready') {
      this.updateParticles(dt);
      return;
    }

    // Paddle Movement
    this.paddle.x += this.paddle.dx * this.paddle.speed * dt;
    this.paddle.x = Math.max(10, Math.min(this.width - this.paddle.w - 10, this.paddle.x));

    // Laser buff timer
    if (this.paddle.laserActive) {
      this.paddle.laserTimer -= dt;
      if (this.paddle.laserTimer <= 0) {
        this.paddle.laserActive = false;
      }
    }

    // Update Lasers
    for (let i = this.lasers.length - 1; i >= 0; i--) {
      const laser = this.lasers[i];
      laser.y -= laser.speed * dt;
      
      // Check laser vs bricks
      let hit = false;
      for (const brick of this.bricks) {
        if (!brick.alive) continue;
        if (laser.x >= brick.x && laser.x <= brick.x + brick.w &&
            laser.y >= brick.y && laser.y <= brick.y + brick.h) {
          hit = true;
          this.damageBrick(brick);
          break;
        }
      }

      if (hit || laser.y < 0) {
        this.lasers.splice(i, 1);
      }
    }

    // Update Balls
    for (let i = this.balls.length - 1; i >= 0; i--) {
      const b = this.balls[i];

      if (b.attached) {
        b.x = this.paddle.x + this.paddle.w / 2;
        b.y = this.paddle.y - b.radius;
        continue;
      }

      // Ball trail
      b.trail.unshift({ x: b.x, y: b.y });
      if (b.trail.length > 5) b.trail.pop();

      b.x += b.vx * dt;
      b.y += b.vy * dt;

      // Wall Collisions
      if (b.x - b.radius <= 0) {
        b.x = b.radius;
        b.vx = Math.abs(b.vx);
        window.soundEngine.playBounce();
      } else if (b.x + b.radius >= this.width) {
        b.x = this.width - b.radius;
        b.vx = -Math.abs(b.vx);
        window.soundEngine.playBounce();
      }

      if (b.y - b.radius <= 0) {
        b.y = b.radius;
        b.vy = Math.abs(b.vy);
        window.soundEngine.playBounce();
      }

      // Paddle Collision
      if (
        b.y + b.radius >= this.paddle.y &&
        b.y - b.radius <= this.paddle.y + this.paddle.h &&
        b.x >= this.paddle.x - 5 &&
        b.x <= this.paddle.x + this.paddle.w + 5 &&
        b.vy > 0
      ) {
        // Calculate bounce angle based on where it hit the paddle
        const hitPos = (b.x - (this.paddle.x + this.paddle.w / 2)) / (this.paddle.w / 2);
        const maxAngle = Math.PI * 0.42; // ~75 degrees
        const angle = hitPos * maxAngle;
        const speed = Math.min(540, Math.sqrt(b.vx * b.vx + b.vy * b.vy) * 1.02);

        b.vx = speed * Math.sin(angle);
        b.vy = -speed * Math.cos(angle);
        b.y = this.paddle.y - b.radius;

        this.combo = 0; // Reset combo on paddle bounce
        window.soundEngine.playBounce();
        this.createHitSparks(b.x, b.y, '#00f0ff', 6);
      }

      // Brick Collision
      for (const brick of this.bricks) {
        if (!brick.alive) continue;

        if (
          b.x + b.radius > brick.x &&
          b.x - b.radius < brick.x + brick.w &&
          b.y + b.radius > brick.y &&
          b.y - b.radius < brick.y + brick.h
        ) {
          // Determine collision side
          const overlapLeft = (b.x + b.radius) - brick.x;
          const overlapRight = (brick.x + brick.w) - (b.x - b.radius);
          const overlapTop = (b.y + b.radius) - brick.y;
          const overlapBottom = (brick.y + brick.h) - (b.y - b.radius);

          const minOverlapX = Math.min(overlapLeft, overlapRight);
          const minOverlapY = Math.min(overlapTop, overlapBottom);

          if (minOverlapX < minOverlapY) {
            b.vx = -b.vx;
          } else {
            b.vy = -b.vy;
          }

          this.combo++;
          if (this.combo > this.maxCombo) this.maxCombo = this.combo;
          this.damageBrick(brick);
          break;
        }
      }

      // Ball lost below canvas
      if (b.y - b.radius > this.height) {
        this.balls.splice(i, 1);
      }
    }

    // Check if all balls lost
    if (this.balls.length === 0 && this.state === 'playing') {
      this.lives--;
      this.combo = 0;
      window.soundEngine.playHit();

      if (this.lives <= 0) {
        this.state = 'gameover';
        window.soundEngine.playGameOver();
        this.app.saveHighScore(this.id, this.score);
      } else {
        this.spawnBall(true);
        this.state = 'ready';
      }
    }

    // Update Power-ups
    for (let i = this.powerups.length - 1; i >= 0; i--) {
      const p = this.powerups[i];
      p.y += p.speed * dt;
      p.rotation += 2 * dt;

      // Check pickup
      if (
        p.y + 12 >= this.paddle.y &&
        p.y - 12 <= this.paddle.y + this.paddle.h &&
        p.x + 12 >= this.paddle.x &&
        p.x - 12 <= this.paddle.x + this.paddle.w
      ) {
        this.applyPowerup(p.type);
        window.soundEngine.playPowerup();
        this.createHitSparks(p.x, p.y, p.color, 15);
        this.powerups.splice(i, 1);
        continue;
      }

      if (p.y > this.height) {
        this.powerups.splice(i, 1);
      }
    }

    // Check level clear
    const remainingBricks = this.bricks.filter(b => b.alive).length;
    if (remainingBricks === 0 && this.state === 'playing') {
      this.level++;
      this.score += 500 * this.level;
      window.soundEngine.playVictory();
      this.initBricks();
      this.balls = [];
      this.spawnBall(true);
      this.state = 'ready';
    }

    this.updateParticles(dt);
  }

  damageBrick(brick) {
    brick.hits--;
    if (brick.hits <= 0) {
      brick.alive = false;
      const points = brick.points * (1 + Math.floor(this.combo / 3));
      this.score += points;
      window.soundEngine.playHit();
      this.createHitSparks(brick.x + brick.w / 2, brick.y + brick.h / 2, brick.color, 16);

      // Bomb brick explodes surrounding bricks
      if (brick.type === 'bomb') {
        window.soundEngine.playExplosion();
        this.explodeAdjacent(brick);
      }

      // Chance to drop power-up
      if (Math.random() < 0.22) {
        this.spawnPowerup(brick.x + brick.w / 2, brick.y + brick.h / 2);
      }
    } else {
      window.soundEngine.playBounce();
      this.createHitSparks(brick.x + brick.w / 2, brick.y + brick.h / 2, brick.color, 6);
    }
  }

  explodeAdjacent(centerBrick) {
    const blastRadius = 90;
    this.bricks.forEach(b => {
      if (!b.alive) return;
      const dist = Math.hypot((b.x + b.w / 2) - (centerBrick.x + centerBrick.w / 2), (b.y + b.h / 2) - (centerBrick.y + centerBrick.h / 2));
      if (dist <= blastRadius) {
        b.alive = false;
        this.score += b.points;
        this.createHitSparks(b.x + b.w / 2, b.y + b.h / 2, '#ff3300', 12);
      }
    });
  }

  spawnPowerup(x, y) {
    const types = [
      { type: 'wide', label: 'W', color: '#00f0ff', name: 'Wide Paddle' },
      { type: 'multiball', label: 'M', color: '#ff007f', name: 'Multi-Ball' },
      { type: 'laser', label: 'L', color: '#ffe600', name: 'Laser Blaster' },
      { type: 'life', label: '+1', color: '#00ff66', name: 'Extra Life' }
    ];
    const chosen = types[Math.floor(Math.random() * types.length)];
    this.powerups.push({
      x: x,
      y: y,
      type: chosen.type,
      label: chosen.label,
      color: chosen.color,
      speed: 130,
      rotation: 0
    });
  }

  applyPowerup(type) {
    if (type === 'wide') {
      this.paddle.w = this.paddle.baseW * 1.5;
      setTimeout(() => {
        this.paddle.w = this.paddle.baseW;
      }, 10000);
    } else if (type === 'multiball') {
      const active = this.balls[0] || { x: this.paddle.x + this.paddle.w / 2, y: this.paddle.y - 10 };
      for (let i = 0; i < 2; i++) {
        const ball = {
          x: active.x,
          y: active.y,
          radius: 7,
          vx: (Math.random() - 0.5) * 400,
          vy: -280 - Math.random() * 80,
          attached: false,
          trail: []
        };
        this.balls.push(ball);
      }
    } else if (type === 'laser') {
      this.paddle.laserActive = true;
      this.paddle.laserTimer = 10;
    } else if (type === 'life') {
      this.lives = Math.min(5, this.lives + 1);
    }
  }

  fireLaser() {
    if (!this.paddle.laserActive || this.state !== 'playing') return;
    this.lasers.push({
      x: this.paddle.x + 8,
      y: this.paddle.y,
      speed: 600
    });
    this.lasers.push({
      x: this.paddle.x + this.paddle.w - 8,
      y: this.paddle.y,
      speed: 600
    });
    window.soundEngine.playLaser();
  }

  createHitSparks(x, y, color, count) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 60 + Math.random() * 180;
      this.particles.push({
        x: x,
        y: y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color: color,
        size: 2 + Math.random() * 3,
        alpha: 1,
        life: 0.3 + Math.random() * 0.4
      });
    }
  }

  updateParticles(dt) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.alpha -= dt / p.life;
      if (p.alpha <= 0) {
        this.particles.splice(i, 1);
      }
    }
  }

  handleInput(action, active, val) {
    if (action === 'left') {
      this.paddle.dx = active ? -1 : (this.paddle.dx === -1 ? 0 : this.paddle.dx);
    } else if (action === 'right') {
      this.paddle.dx = active ? 1 : (this.paddle.dx === 1 ? 0 : this.paddle.dx);
    } else if (action === 'action' && active) {
      if (this.state === 'ready' || this.state === 'gameover') {
        this.start();
      } else if (this.state === 'playing') {
        this.fireLaser();
      }
    } else if (action === 'pointermove') {
      // Direct mouse/touch move
      const rect = this.canvas.getBoundingClientRect();
      const scaleX = this.canvas.width / rect.width;
      const mouseX = (val.clientX - rect.left) * scaleX;
      this.paddle.x = Math.max(10, Math.min(this.width - this.paddle.w - 10, mouseX - this.paddle.w / 2));
    } else if (action === 'pointerdown') {
      if (this.state === 'ready' || this.state === 'gameover') {
        this.start();
      } else if (this.state === 'playing') {
        this.fireLaser();
      }
    }
  }

  draw() {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.width, this.height);

    // Subtle neon grid background
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.04)';
    ctx.lineWidth = 1;
    const gridStep = 40;
    for (let x = 0; x < this.width; x += gridStep) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, this.height);
      ctx.stroke();
    }
    for (let y = 0; y < this.height; y += gridStep) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(this.width, y);
      ctx.stroke();
    }

    // Draw Bricks
    for (const b of this.bricks) {
      if (!b.alive) continue;
      ctx.save();
      ctx.shadowColor = b.color;
      ctx.shadowBlur = b.type === 'bomb' ? 12 : 8;
      ctx.fillStyle = b.color;
      ctx.fillRect(b.x, b.y, b.w, b.h);

      // Border highlight
      ctx.strokeStyle = b.border;
      ctx.lineWidth = 1.5;
      ctx.strokeRect(b.x + 1, b.y + 1, b.w - 2, b.h - 2);

      // Icon for special bricks
      if (b.type === 'bomb') {
        ctx.fillStyle = '#ffffff';
        ctx.font = '10px "Press Start 2P", monospace';
        ctx.textAlign = 'center';
        ctx.fillText('💣', b.x + b.w / 2, b.y + 14);
      } else if (b.type === 'hard') {
        ctx.fillStyle = 'rgba(255,255,255,0.7)';
        ctx.font = '10px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(b.hits === 2 ? '★' : '•', b.x + b.w / 2, b.y + 14);
      }
      ctx.restore();
    }

    // Draw Lasers
    for (const l of this.lasers) {
      ctx.save();
      ctx.shadowColor = '#ffe600';
      ctx.shadowBlur = 10;
      ctx.fillStyle = '#fffb80';
      ctx.fillRect(l.x - 2, l.y, 4, 14);
      ctx.restore();
    }

    // Draw Power-ups
    for (const p of this.powerups) {
      ctx.save();
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 10;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 11, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 10px monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(p.label, p.x, p.y);
      ctx.restore();
    }

    // Draw Paddle
    ctx.save();
    const paddleGradient = ctx.createLinearGradient(this.paddle.x, this.paddle.y, this.paddle.x, this.paddle.y + this.paddle.h);
    paddleGradient.addColorStop(0, this.paddle.laserActive ? '#ffe600' : '#00f0ff');
    paddleGradient.addColorStop(1, this.paddle.laserActive ? '#ff5500' : '#0072ff');

    ctx.shadowColor = this.paddle.laserActive ? '#ffe600' : '#00f0ff';
    ctx.shadowBlur = 15;
    ctx.fillStyle = paddleGradient;
    ctx.beginPath();
    ctx.roundRect(this.paddle.x, this.paddle.y, this.paddle.w, this.paddle.h, 6);
    ctx.fill();

    // Paddle Center Accent
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(this.paddle.x + this.paddle.w / 2 - 12, this.paddle.y + 2, 24, 3);
    ctx.restore();

    // Draw Balls
    for (const b of this.balls) {
      ctx.save();
      // Draw ball trail
      b.trail.forEach((pos, idx) => {
        ctx.fillStyle = `rgba(0, 240, 255, ${0.4 - idx * 0.08})`;
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, b.radius * (1 - idx * 0.15), 0, Math.PI * 2);
        ctx.fill();
      });

      // Ball head
      ctx.shadowColor = '#00f0ff';
      ctx.shadowBlur = 14;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Draw Particles
    for (const p of this.particles) {
      ctx.save();
      ctx.fillStyle = p.color;
      ctx.globalAlpha = Math.max(0, p.alpha);
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 6;
      ctx.fillRect(p.x, p.y, p.size, p.size);
      ctx.restore();
    }

    // Draw HUD
    this.drawHUD(ctx);

    // Overlay Screens
    if (this.state === 'ready') {
      this.drawCenteredBanner(ctx, 'PRESS SPACE OR TAP TO LAUNCH', 'A / D 또는 좌우 화살표로 패들 이동');
    } else if (this.state === 'gameover') {
      this.drawCenteredBanner(ctx, 'GAME OVER', `최종 점수: ${this.score} (SPACE / 터치로 재시작)`, '#ff0055');
    }
  }

  drawHUD(ctx) {
    ctx.save();
    ctx.font = '12px "Press Start 2P", monospace';
    ctx.fillStyle = '#00f0ff';
    ctx.textAlign = 'left';
    ctx.fillText(`SCORE: ${this.score}`, 18, 26);

    ctx.fillStyle = '#ffe600';
    ctx.fillText(`LVL: ${this.level}`, 240, 26);

    if (this.combo > 1) {
      ctx.fillStyle = '#ff007f';
      ctx.fillText(`COMBO x${this.combo}`, 340, 26);
    }

    // Lives
    ctx.textAlign = 'right';
    let hearts = '';
    for (let i = 0; i < this.lives; i++) hearts += '❤️ ';
    ctx.fillStyle = '#ff0055';
    ctx.font = '14px sans-serif';
    ctx.fillText(hearts, this.width - 18, 26);
    ctx.restore();
  }

  drawCenteredBanner(ctx, title, subtitle, color = '#00f0ff') {
    ctx.save();
    ctx.fillStyle = 'rgba(10, 15, 30, 0.75)';
    ctx.fillRect(0, this.height / 2 - 50, this.width, 100);

    ctx.shadowColor = color;
    ctx.shadowBlur = 12;
    ctx.fillStyle = color;
    ctx.font = '18px "Press Start 2P", monospace';
    ctx.textAlign = 'center';
    ctx.fillText(title, this.width / 2, this.height / 2 - 8);

    ctx.shadowBlur = 0;
    ctx.fillStyle = '#94a3b8';
    ctx.font = '12px "Pretendard", sans-serif';
    ctx.fillText(subtitle, this.width / 2, this.height / 2 + 25);
    ctx.restore();
  }

  destroy() {
    this.particles = [];
  }
}

window.BreakoutGame = BreakoutGame;
